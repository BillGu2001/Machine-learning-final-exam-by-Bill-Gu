import os
import shutil


def to_sample(folder_list, out_path):
    """
    把spam中的邮件以及ham中的邮件收集重命名放入sample
    """
    if not os.path.exists(out_path):
        os.mkdir(out_path)
    else:
        shutil.rmtree(out_path)
        os.mkdir(out_path)

    for folder in folder_list:
        spam_path = f"{folder}/spam"
        file_name_list = os.listdir(spam_path)
        for file_name in file_name_list:
            source = f"{spam_path}/{file_name}"
            destination = f"{out_path}/{file_name}"
            shutil.copyfile(source,destination)

        ham_path = f"{folder}/ham"
        file_name_list = os.listdir(ham_path)
        for file_name in file_name_list:
            source = f"{ham_path}/{file_name}"
            destination = f"{out_path}/{file_name}"
            shutil.copyfile(source,destination)


if __name__ == "__main__":
    # 将6个Enron的spam、ham文件夹中的邮件整合放入根目录下的sample文件夹
    folder_list = [f"enron{i}" for i in range(1, 7)]
    out_path = "sample"
    to_sample(folder_list, out_path)

    # 将每个Enron的spam、ham文件夹中的邮件整合放入各自的sample文件夹
    for i in range(1, 7):
        folder_list = [f"enron{i}"]
        out_path = f"enron{i}/sample"
        to_sample(folder_list, out_path)