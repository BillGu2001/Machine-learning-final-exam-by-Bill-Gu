import nltk
import pickle


def feature_construct(in_path):
    X_data = []
    Y_data = []

    print('==================Read WORD_DICTIONARY===================')
    word_dict = pickle.load(open('WORD_DICTIONARY.pkl', 'rb'))
    print(f'The length of WORD_DICTIONARY is {len(word_dict)}')

    print('==========Read Email=========')
    with open(in_path, 'r', encoding='utf-8', errors='ignore') as emails:
        spam_num = 0
        ham_num = 0
        for email in emails.readlines():
            word_list = nltk.tokenize.word_tokenize(email)  # 以单词分割
            # 提取特征
            print('==========Get features=========')
            x = [word_list.count(word) for word in word_dict]

            X_data.append(x)
            Y_data.append(word_list[-1])

            if word_list[-1] == 'SPAM':
                spam_num += 1

            if word_list[-1] == 'HAM':
                ham_num += 1

            print(f'Spam num = {spam_num}')
            print(f'Ham num = {ham_num}')

    print('==========Save all samples and corresponding labels=========')
    pickle.dump(X_data, open('X_data.pkl', 'wb'))
    pickle.dump(Y_data, open('Y_data.pkl', 'wb'))


if __name__ == "__main__":
    feature_construct("preprocessed_email/preprocessed_email_text.txt")