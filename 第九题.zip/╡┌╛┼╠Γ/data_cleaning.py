import os
import nltk
import shutil
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer


def data_cleaning(in_folder_path, out_folder_path):
    WNL = WordNetLemmatizer()

    # out_folder_path = "preprocessed_email"
    # in_folder_path = "sample"

    if not os.path.exists(out_folder_path):
        os.mkdir(out_folder_path)
        print('Create Format_sample')
    else:
        shutil.rmtree(out_folder_path)
        os.mkdir(out_folder_path)
        print('Create Format_sample')

    sample_name_list = os.listdir(in_folder_path)
    ham_num = 0
    spam_num = 0
    with open(os.path.join(out_folder_path, 'preprocessed_email_text.txt'), 'w', encoding='utf-8') as F_email:

        for sample_name in sample_name_list:
            # print(sample_name)
            with open(os.path.join(in_folder_path, sample_name), 'r', encoding='utf-8', errors='ignore') as email:
                text = email.read()
                word_list = nltk.tokenize.word_tokenize(text)  # 切分文档（结果会包括其他字符）
                stop_words = stopwords.words('english')  # 列出nltk结束词
                # 去除停用词以及单词数字之外的符号，同时把剩下的词先转化为小写，然后进行动词还原、名词还原
                word_list_1 = [WNL.lemmatize(WNL.lemmatize(word.lower(), 'v'), 'n') for word in word_list
                               if word.isalnum() and word not in stop_words]
                # 把清理后的email 保存到文件中 一个邮件保存为一行
                for word in word_list_1:
                    F_email.write(word+' ')
                if sample_name[-7] == 'h':
                    F_email.write('HAM\n')   # 在一行末尾标记是不是垃圾邮件
                    ham_num += 1
                    print(f'{sample_name} is not SPAM')
                elif sample_name[-7] == 'p':
                    F_email.write('SPAM\n')
                    spam_num += 1
                    print(f'{sample_name} is SPAM')

    print(f'Spam num {spam_num} Ham num {ham_num}')


if __name__ == "__main__":
    data_cleaning("sample", "preprocessed_email")