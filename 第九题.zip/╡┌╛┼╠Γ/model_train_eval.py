import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
import joblib
import numpy as np
import pandas as pd


def model_train_eval(model_name, X_data, Y_data):
    train_x, test_x, train_y, test_y = train_test_split(X_data, Y_data, test_size=0.3, random_state=369)

    train_num = len(train_x)
    test_num = len(test_x)
    total_num = train_num+test_num
    print(f'train_num :{train_num} test_num :{test_num} total_num :{total_num}')

    if model_name == "RF":
        RFC = RandomForestClassifier(n_estimators=1000, oob_score=True)
        RFC.fit(train_x, train_y)
        print('=============Saving Model=============')
        joblib.dump(RFC, 'Detector_Model.m')
        test_y_pred = RFC.predict(test_x)

    elif model_name == "Logistic":
        Logistic = LogisticRegression(random_state=0)
        Logistic.fit(train_x, train_y)
        test_y_pred = Logistic.predict(test_x)

    elif model_name == "SVM":
        SVM = SVC(kernel="linear", random_state=0)
        SVM.fit(train_x, train_y)
        test_y_pred = SVM.predict(test_x)

    else:
        print("函数不支持该模型！")
        return

    print(pd.crosstab(test_y, test_y_pred))
    confusion_matrix = np.array(pd.crosstab(test_y, test_y_pred))
    print('====================================')
    print(f'Accuracy：{(confusion_matrix[0][0]+confusion_matrix[1][1])/confusion_matrix.sum()}')


if __name__ == "__main__":
    X = pickle.load(open('X_data.pkl', 'rb'))
    Y = pickle.load(open('Y_data.pkl', 'rb'))
    model_train_eval("RF", X, Y)
    model_train_eval("SVM", X, Y)
    model_train_eval("Logistic", X, Y)




