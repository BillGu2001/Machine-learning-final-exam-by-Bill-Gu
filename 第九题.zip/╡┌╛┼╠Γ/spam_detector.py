import os
import joblib
import pickle
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import numpy as np


def spam_detector(including="all", emails=None):
    WNL = WordNetLemmatizer()

    # 读取字典
    word_dict = pickle.load(open('WORD_DICTIONARY.pkl', 'rb'))
    # 读取训练好的模型
    RFC = joblib.load('Detector_Model.m')

    if emails is None:
        if including == "all":
            input_path = "sample"

        elif including in ["enron1", "enron2", "enron3", "enron4", "enron5", "enron6"]:
            input_path = f"{including}/sample"

        else:
            print("检测邮件范围不合法！")
            return

        for email_name in os.listdir(input_path):
            with open(os.path.join(input_path, email_name), 'r', encoding='utf-8', errors='ignore') as email_text:
                email = email_text.read()
                word_list = word_tokenize(email)  # 切分为单个的词
                stop_words = stopwords.words('english')
                word_list0 = [WNL.lemmatize(WNL.lemmatize(word.lower(), 'v'), 'n') for word in word_list if
                              word.isalnum() and word not in stop_words]
                # 生成邮件向量
                x = np.array([[word_list0.count(word) for word in word_dict]])
                y = RFC.predict(x)
                if y == 'SPAM':
                    print(f'{email_name} is a junk email')
                elif y == 'HAM':
                    print(f'{email_name} is a legitimate email')

    elif isinstance(emails, str):
        email_name = emails
        input_path = "sample"
        with open(os.path.join(input_path, email_name), 'r', encoding='utf-8', errors='ignore') as email_text:
            email = email_text.read()
            word_list = word_tokenize(email)  # 切分为单个的词
            stop_words = stopwords.words('english')
            word_list0 = [WNL.lemmatize(WNL.lemmatize(word.lower(), 'v'), 'n') for word in word_list if
                          word.isalnum() and word not in stop_words]
            # 生成邮件向量
            x = np.array([[word_list0.count(word) for word in word_dict]])
            y = RFC.predict(x)
            if y == 'SPAM':
                print(f'{email_name} is a junk email')
            elif y == 'HAM':
                print(f'{email_name} is a legitimate email')

    elif isinstance(emails, list):
        input_path = "sample"
        for email_name in emails:
            with open(os.path.join(input_path, email_name), 'r', encoding='utf-8', errors='ignore') as email_text:
                email = email_text.read()
                word_list = word_tokenize(email)  # 切分为单个的词
                stop_words = stopwords.words('english')
                word_list0 = [WNL.lemmatize(WNL.lemmatize(word.lower(), 'v'), 'n') for word in word_list if
                              word.isalnum() and word not in stop_words]
                # 生成邮件向量
                x = np.array([[word_list0.count(word) for word in word_dict]])
                y = RFC.predict(x)
                if y == 'SPAM':
                    print(f'{email_name} is a junk email')
                elif y == 'HAM':
                    print(f'{email_name} is a legitimate email')

    else:
        print("检测邮件名不合法！")
        return


if __name__ == "__main__":
    spam_detector(including="enron1", emails=["0001.1999-12-10.farmer.ham.txt", "0006.2003-12-18.GP.spam.txt"])

