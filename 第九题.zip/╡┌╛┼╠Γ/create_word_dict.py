import pickle
import nltk


def create_word_dict(in_path, out_path):
    word_frequency = 100  # 词频率小于100的单词将不在辞典中

    with open(in_path, 'r', encoding='utf-8', errors='ignore') as email:
        text = email.read()
        text = nltk.tokenize.word_tokenize(text)
        word_dict1 = dict(nltk.FreqDist(text))

        dict_word = []
        for key, value in word_dict1.items():
            if value > word_frequency:
                dict_word.append(key)

        dict_word.remove('SPAM')
        dict_word.remove('HAM')
        dict_word.remove('subject')
        pickle.dump(dict_word, open(out_path, 'wb'))
        print('==========================================')
        print(f'The length of WORD_DICTIONARY is {len(dict_word)}')


if __name__ == "__main__":
    create_word_dict("preprocessed_email/preprocessed_email_text.txt", "WORD_DICTIONARY.pkl")

